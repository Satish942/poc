-- Runs on every container startup, connected as APP_USER (syncuser) to FREEPDB1.
-- Central starts with an empty PRODUCTS table — it gets populated by the sync service.

BEGIN
  EXECUTE IMMEDIATE '
    CREATE TABLE products (
      id          NUMBER PRIMARY KEY,
      name        VARCHAR2(100) NOT NULL,
      price       NUMBER(10,2) NOT NULL,
      updated_at  TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL
    )';
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -955 THEN  -- ORA-00955: name already used by an existing object
      RAISE;
    END IF;
END;
/
