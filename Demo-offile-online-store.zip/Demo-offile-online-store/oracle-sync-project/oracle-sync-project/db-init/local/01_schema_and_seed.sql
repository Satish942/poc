-- Runs on every container startup, connected as APP_USER (syncuser) to FREEPDB1.
-- Wrapped in PL/SQL so re-running on container restart doesn't fail on "already exists".

BEGIN
  DBMS_OUTPUT.PUT_LINE('Creating PRODUCTS table...');
  EXECUTE IMMEDIATE '
    CREATE TABLE products (
      id          NUMBER PRIMARY KEY,
      name        VARCHAR2(100) NOT NULL,
      price       NUMBER(10,2) NOT NULL,
      updated_at  TIMESTAMP DEFAULT SYSTIMESTAMP NOT NULL
    )';
  DBMS_OUTPUT.PUT_LINE('PRODUCTS table created.');
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -955 THEN  -- ORA-00955: name already used by an existing object
      DBMS_OUTPUT.PUT_LINE('Error creating PRODUCTS: ' || SQLERRM);
      RAISE;
    ELSE
      DBMS_OUTPUT.PUT_LINE('PRODUCTS table already exists.');
    END IF;
END;
/

BEGIN
  DBMS_OUTPUT.PUT_LINE('Creating SYNC_METADATA table...');
  EXECUTE IMMEDIATE '
    CREATE TABLE sync_metadata (
      table_name      VARCHAR2(50) PRIMARY KEY,
      last_synced_at  TIMESTAMP
    )';
  DBMS_OUTPUT.PUT_LINE('SYNC_METADATA table created.');
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -955 THEN
      DBMS_OUTPUT.PUT_LINE('Error creating SYNC_METADATA: ' || SQLERRM);
      RAISE;
    ELSE
      DBMS_OUTPUT.PUT_LINE('SYNC_METADATA table already exists.');
    END IF;
END;
/

BEGIN
  DBMS_OUTPUT.PUT_LINE('Inserting seed data...');
  INSERT INTO products (id, name, price, updated_at) VALUES (1, 'Wireless Mouse', 799.00, SYSTIMESTAMP);
  INSERT INTO products (id, name, price, updated_at) VALUES (2, 'USB-C Hub', 1499.00, SYSTIMESTAMP);
  INSERT INTO products (id, name, price, updated_at) VALUES (3, 'Mechanical Keyboard', 3299.00, SYSTIMESTAMP);
  INSERT INTO products (id, name, price, updated_at) VALUES (4, '27-inch Monitor', 15999.00, SYSTIMESTAMP);
  INSERT INTO products (id, name, price, updated_at) VALUES (5, 'Laptop Stand', 1199.00, SYSTIMESTAMP);
  COMMIT;
  DBMS_OUTPUT.PUT_LINE('Seed data inserted.');
EXCEPTION
  WHEN OTHERS THEN
    IF SQLCODE != -1 THEN  -- Not a duplicate insertion
      DBMS_OUTPUT.PUT_LINE('Error inserting seed data: ' || SQLERRM);
      RAISE;
    ELSE
      DBMS_OUTPUT.PUT_LINE('Seed data already exists.');
    END IF;
END;
/
