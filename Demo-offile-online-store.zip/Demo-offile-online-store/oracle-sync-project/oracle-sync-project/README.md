# Oracle DB Sync Service (local → central)

Two Oracle Database Free containers plus a Java (Spring Boot) microservice
that syncs the `PRODUCTS` table from the local instance to the central
instance on a schedule.

## What's in here

```
docker-compose.yml          # wires both DBs + the sync service together
db-init/local/               # schema + seed data for the LOCAL (source) DB
db-init/central/             # schema only for the CENTRAL (target) DB — starts empty
sync-service/                # Spring Boot 3 / Java 17 sync microservice
  ├── Dockerfile              # multi-stage build (Maven → JRE runtime)
  ├── pom.xml
  └── src/main/java/com/retail/sync/
      ├── SyncServiceApplication.java
      ├── config/DataSourceConfig.java     # two DataSource + JdbcTemplate beans
      ├── service/DataSyncService.java     # the actual sync logic
      ├── scheduler/SyncScheduler.java     # runs it on a cron
      └── controller/SyncController.java   # manual trigger + status endpoints
```

## How the sync works

1. **Watermark**: the local DB has a `sync_metadata` table tracking the last
   `updated_at` timestamp that was successfully pushed to central, per table.
2. **Delta read**: on each run, the service reads only local `products` rows
   with `updated_at` newer than the watermark.
3. **Upsert**: those rows are pushed to central using an Oracle `MERGE`
   statement (update if the id exists and is older, insert if it doesn't).
4. **Advance watermark**: only after the merge succeeds does the local
   watermark move forward — so a failed run retries the same rows next time
   instead of silently skipping them.
5. **Schedule**: a Spring `@Scheduled` job runs this on the cron defined by
   `SYNC_CRON` (default: every 2 minutes). You can also trigger it manually.

This is a one-way (local → central) sync of a single table, intentionally
kept simple as a working example — see "Extending this" below for what a
production version would add.

## Running it

```bash
docker compose up -d --build
```

First boot of the two Oracle Free containers takes 2–4 minutes (Oracle has
to initialize the database files). `sync-service` won't start until both
report healthy — `docker compose ps` will show `(healthy)` on both DB
containers once ready.

Watch the sync service logs:

```bash
docker compose logs -f sync-service
```

## Verifying the sync

**Manually trigger a sync run** instead of waiting for the schedule:

```bash
curl -X POST http://localhost:8080/api/sync/trigger
```

**Check the last run's status:**

```bash
curl http://localhost:8080/api/sync/status
```

**Compare row counts directly** (using `sqlplus` from inside each container):

```bash
docker exec -it oracle-local  sqlplus syncuser/SyncPass123@//localhost:1521/FREEPDB1 <<< "SELECT COUNT(*) FROM products;"
docker exec -it oracle-central sqlplus syncuser/SyncPass123@//localhost:1521/FREEPDB1 <<< "SELECT COUNT(*) FROM products;"
```

**Test an actual sync**: insert or update a row on local, then trigger a
sync and confirm it shows up on central:

```bash
docker exec -it oracle-local sqlplus syncuser/SyncPass123@//localhost:1521/FREEPDB1 <<'SQL'
UPDATE products SET price = 999.00, updated_at = SYSTIMESTAMP WHERE id = 1;
COMMIT;
SQL

curl -X POST http://localhost:8080/api/sync/trigger

docker exec -it oracle-central sqlplus syncuser/SyncPass123@//localhost:1521/FREEPDB1 <<< "SELECT id, price FROM products WHERE id = 1;"
```

## Configuration

All of these are environment variables on the `sync-service` container
(set in `docker-compose.yml`):

| Variable | Default | Purpose |
|---|---|---|
| `LOCAL_DB_URL` / `CENTRAL_DB_URL` | — | JDBC URLs for each instance |
| `LOCAL_DB_USER` / `CENTRAL_DB_USER` | `syncuser` | DB user |
| `LOCAL_DB_PASSWORD` / `CENTRAL_DB_PASSWORD` | — | DB password |
| `SYNC_CRON` | `0 */2 * * * *` | Spring cron: sec min hour day month weekday |
| `SYNC_BATCH_SIZE` | `500` | Rows per JDBC batch on the MERGE |

## Extending this toward production

- **Multiple tables**: generalize `DataSyncService` to loop over a
  configured list of tables instead of the single hard-coded `PRODUCTS`.
- **Deletes**: this example only syncs inserts/updates. Real deployments
  usually add a `deleted_flag` + soft delete, since Oracle has no built-in
  "what got deleted since X" signal without triggers or Golden Gate/CDC.
  Adding an `is_deleted` propagates in the same way. Adding an is_deleted
  column and syncing that flag is the simplest approach without CDC tooling.
- **Bidirectional sync**: this is one-way (local → central). Two-way sync
  needs a real conflict-resolution rule (see the offline-store architecture
  discussion above) plus per-row origin tracking.
- **Retry/backoff**: currently a failed run just logs and waits for the
  next scheduled tick. For faster recovery, add exponential backoff retries
  within the run itself.
- **Observability**: `spring-boot-starter-actuator` is already included;
  wire `/actuator/health` and the `/api/sync/status` endpoint into your
  monitoring stack instead of just reading container logs.
