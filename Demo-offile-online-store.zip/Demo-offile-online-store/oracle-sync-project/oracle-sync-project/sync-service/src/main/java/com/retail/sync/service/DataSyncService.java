package com.retail.sync.service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.retail.sync.model.SyncResult;

/**
 * Syncs the PRODUCTS table from the local (source) Oracle instance to the
 * central (target) Oracle instance.
 *
 * Pattern: watermark-based delta read + MERGE upsert.
 *  1. Read the last-synced timestamp for this table from LOCAL.sync_metadata.
 *  2. Pull every local row changed after that timestamp.
 *  3. MERGE (upsert) each row into the central table.
 *  4. Only after the merge succeeds, advance the local watermark to the
 *     newest updated_at just processed — so a failed run is safely retried
 *     on the next schedule instead of skipping rows.
 */
@Service
public class DataSyncService {

    private static final Logger log = LoggerFactory.getLogger(DataSyncService.class);

    private static final String SELECT_CHANGED_ROWS =
            "SELECT id, name, price, updated_at FROM products " +
            "WHERE updated_at > ? ORDER BY updated_at";

    private static final String MERGE_INTO_CENTRAL =
            "MERGE INTO products tgt " +
            "USING (SELECT ? AS id, ? AS name, ? AS price, ? AS updated_at FROM dual) src " +
            "ON (tgt.id = src.id) " +
            "WHEN MATCHED THEN UPDATE SET tgt.name = src.name, tgt.price = src.price, tgt.updated_at = src.updated_at " +
            "  WHERE tgt.updated_at < src.updated_at " +
            "WHEN NOT MATCHED THEN INSERT (id, name, price, updated_at) " +
            "  VALUES (src.id, src.name, src.price, src.updated_at)";

    private static final String SELECT_WATERMARK =
            "SELECT last_synced_at FROM sync_metadata WHERE table_name = ?";

    private static final String UPDATE_WATERMARK =
            "UPDATE sync_metadata SET last_synced_at = ? WHERE table_name = ?";

    private static final String INSERT_WATERMARK =
            "INSERT INTO sync_metadata (table_name, last_synced_at) VALUES (?, ?)";

    private final JdbcTemplate localJdbcTemplate;
    private final JdbcTemplate centralJdbcTemplate;

    @Value("${sync.table-name}")
    private String tableName;

    @Value("${sync.batch-size}")
    private int batchSize;

    private final AtomicReference<SyncResult> lastResult = new AtomicReference<>();

    public DataSyncService(@Qualifier("localJdbcTemplate") JdbcTemplate localJdbcTemplate,
                            @Qualifier("centralJdbcTemplate") JdbcTemplate centralJdbcTemplate) {
        this.localJdbcTemplate = localJdbcTemplate;
        this.centralJdbcTemplate = centralJdbcTemplate;
    }

    public SyncResult getLastResult() {
        return lastResult.get();
    }

    /**
     * Runs one sync pass. Synchronized so an overlapping scheduled trigger
     * (e.g. a manual call via the REST endpoint while the cron run is still
     * in flight) can't run concurrently against the same watermark.
     */
    public synchronized SyncResult syncProducts() {
        LocalDateTime startedAt = LocalDateTime.now();
        log.info("Starting sync run for table {}", tableName);

        try {
            Timestamp watermark = readWatermark();

            List<Object[]> changedRows = localJdbcTemplate.query(
                    SELECT_CHANGED_ROWS,
                    (rs, rowNum) -> new Object[] {
                            rs.getLong("id"),
                            rs.getString("name"),
                            rs.getBigDecimal("price"),
                            rs.getTimestamp("updated_at")
                    },
                    watermark
            );

            if (changedRows.isEmpty()) {
                log.info("No changes since {}. Central is already up to date.", watermark);
                SyncResult result = new SyncResult(tableName, "UP_TO_DATE", 0, startedAt, LocalDateTime.now(), null);
                lastResult.set(result);
                return result;
            }

            for (int i = 0; i < changedRows.size(); i += batchSize) {
                List<Object[]> batch = changedRows.subList(i, Math.min(i + batchSize, changedRows.size()));
                centralJdbcTemplate.batchUpdate(MERGE_INTO_CENTRAL, batch);
            }

            Timestamp maxUpdatedAt = watermark;
            for (Object[] row : changedRows) {
                Timestamp rowTs = (Timestamp) row[3];
                if (rowTs.after(maxUpdatedAt)) {
                    maxUpdatedAt = rowTs;
                }
            }
            advanceWatermark(maxUpdatedAt);

            SyncResult result = new SyncResult(tableName, "SUCCESS", changedRows.size(), startedAt, LocalDateTime.now(), null);
            lastResult.set(result);
            log.info("Sync complete. {} row(s) applied to central. New watermark: {}", changedRows.size(), maxUpdatedAt);
            return result;

        } catch (Exception ex) {
            log.error("Sync run failed", ex);
            SyncResult result = new SyncResult(tableName, "FAILED", 0, startedAt, LocalDateTime.now(), ex.getMessage());
            lastResult.set(result);
            return result;
        }
    }

    private Timestamp readWatermark() {
        List<Timestamp> rows = localJdbcTemplate.query(
                SELECT_WATERMARK,
                (rs, rowNum) -> rs.getTimestamp("last_synced_at"),
                tableName
        );
        if (rows.isEmpty() || rows.get(0) == null) {
            return Timestamp.valueOf("1970-01-01 00:00:00");
        }
        return rows.get(0);
    }

    private void advanceWatermark(Timestamp newWatermark) {
        int updated = localJdbcTemplate.update(UPDATE_WATERMARK, newWatermark, tableName);
        if (updated == 0) {
            localJdbcTemplate.update(INSERT_WATERMARK, tableName, newWatermark);
        }
    }
}
