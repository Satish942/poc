package com.retail.sync.model;

import java.time.LocalDateTime;

public class SyncResult {

    private String tableName;
    private String status;
    private int rowsSynced;
    private LocalDateTime startedAt;
    private LocalDateTime completedAt;
    private String errorMessage;

    public SyncResult() {
    }

    public SyncResult(String tableName, String status, int rowsSynced,
                       LocalDateTime startedAt, LocalDateTime completedAt, String errorMessage) {
        this.tableName = tableName;
        this.status = status;
        this.rowsSynced = rowsSynced;
        this.startedAt = startedAt;
        this.completedAt = completedAt;
        this.errorMessage = errorMessage;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getRowsSynced() {
        return rowsSynced;
    }

    public void setRowsSynced(int rowsSynced) {
        this.rowsSynced = rowsSynced;
    }

    public LocalDateTime getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(LocalDateTime startedAt) {
        this.startedAt = startedAt;
    }

    public LocalDateTime getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(LocalDateTime completedAt) {
        this.completedAt = completedAt;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
