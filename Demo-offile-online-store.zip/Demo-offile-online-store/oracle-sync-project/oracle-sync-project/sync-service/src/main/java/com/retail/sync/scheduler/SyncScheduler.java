package com.retail.sync.scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.retail.sync.service.DataSyncService;

@Component
public class SyncScheduler {

    private static final Logger log = LoggerFactory.getLogger(SyncScheduler.class);

    private final DataSyncService dataSyncService;

    public SyncScheduler(DataSyncService dataSyncService) {
        this.dataSyncService = dataSyncService;
    }

    @Scheduled(cron = "${sync.cron}")
    public void runScheduledSync() {
        log.info("Scheduled sync triggered");
        dataSyncService.syncProducts();
    }
}
