package com.retail.sync.config;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.jdbc.core.JdbcTemplate;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

@Configuration
public class DataSourceConfig {

    @Bean(name = "localDataSource")
    @Lazy
    public DataSource localDataSource() {
        String url = System.getenv("LOCAL_DB_URL");
        String user = System.getenv("LOCAL_DB_USER");
        String password = System.getenv("LOCAL_DB_PASSWORD");
        
        System.out.println("@@@ Creating localDataSource");
        System.out.println("@@@ URL from env: " + url);
        System.out.println("@@@ USER from env: " + user);
        
        if (url == null || url.isEmpty()) {
            url = "jdbc:oracle:thin:@localhost:1521/FREEPDB1";
        }
        if (user == null || user.isEmpty()) {
            user = "syncuser";
        }
        if (password == null || password.isEmpty()) {
            password = "SyncPass123";
        }
        
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setUsername(user);
        config.setPassword(password);
        config.setDriverClassName("oracle.jdbc.OracleDriver");
        config.setMaximumPoolSize(5);
        config.setInitializationFailTimeout(60000); // Wait 60 seconds before giving up
        
        HikariDataSource ds = new HikariDataSource(config);
        System.out.println("@@@ localDataSource created: " + ds);
        return ds;
    }

    @Bean(name = "centralDataSource")
    @Lazy
    public DataSource centralDataSource() {
        String url = System.getenv("CENTRAL_DB_URL");
        String user = System.getenv("CENTRAL_DB_USER");
        String password = System.getenv("CENTRAL_DB_PASSWORD");
        
        System.out.println("@@@ Creating centralDataSource");
        System.out.println("@@@ URL from env: " + url);
        System.out.println("@@@ USER from env: " + user);
        
        if (url == null || url.isEmpty()) {
            url = "jdbc:oracle:thin:@localhost:1522/FREEPDB1";
        }
        if (user == null || user.isEmpty()) {
            user = "syncuser";
        }
        if (password == null || password.isEmpty()) {
            password = "SyncPass123";
        }
        
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(url);
        config.setUsername(user);
        config.setPassword(password);
        config.setDriverClassName("oracle.jdbc.OracleDriver");
        config.setMaximumPoolSize(5);
        config.setInitializationFailTimeout(60000); // Wait 60 seconds before giving up
        
        HikariDataSource ds = new HikariDataSource(config);
        System.out.println("@@@ centralDataSource created: " + ds);
        return ds;
    }

    @Bean
    @Lazy
    public JdbcTemplate localJdbcTemplate() {
        return new JdbcTemplate(localDataSource());
    }

    @Bean
    @Lazy
    public JdbcTemplate centralJdbcTemplate() {
        return new JdbcTemplate(centralDataSource());
    }
}
