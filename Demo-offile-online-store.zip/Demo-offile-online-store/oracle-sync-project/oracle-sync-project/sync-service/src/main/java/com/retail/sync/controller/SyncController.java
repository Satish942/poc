package com.retail.sync.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.retail.sync.model.SyncResult;
import com.retail.sync.service.DataSyncService;

@RestController
@RequestMapping("/api/sync")
public class SyncController {

    private final DataSyncService dataSyncService;

    public SyncController(DataSyncService dataSyncService) {
        this.dataSyncService = dataSyncService;
    }

    /** Manually trigger a sync run immediately, outside the schedule. */
    @PostMapping("/trigger")
    public SyncResult triggerSync() {
        return dataSyncService.syncProducts();
    }

    /** Report the outcome of the most recent sync run. */
    @GetMapping("/status")
    public SyncResult status() {
        SyncResult result = dataSyncService.getLastResult();
        return result != null ? result : new SyncResult("PRODUCTS", "NOT_RUN_YET", 0, null, null, null);
    }
}
