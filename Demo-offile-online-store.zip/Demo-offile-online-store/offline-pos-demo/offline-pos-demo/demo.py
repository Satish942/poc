#!/usr/bin/env python3
import json
import os
import sqlite3
import uuid
from datetime import datetime, timezone

ROOT = os.path.dirname(os.path.abspath(__file__))
STORE_DB = os.path.join(ROOT, "store_pos.db")
CENTRAL_DB = os.path.join(ROOT, "central.db")
KAFKA_LOG = os.path.join(ROOT, "kafka_events.jsonl")


def now():
    return datetime.now(timezone.utc).isoformat()


def db(path):
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn


def init_store():
    c = db(STORE_DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS sales (
        local_sale_id TEXT PRIMARY KEY,
        store_id TEXT NOT NULL,
        register_id TEXT NOT NULL,
        receipt_no INTEGER NOT NULL,
        sku TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        total_cents INTEGER NOT NULL,
        payment_status TEXT NOT NULL,
        created_at TEXT NOT NULL,
        sync_status TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS outbox (
        message_id TEXT PRIMARY KEY,
        idempotency_key TEXT NOT NULL UNIQUE,
        message_type TEXT NOT NULL,
        payload TEXT NOT NULL,
        status TEXT NOT NULL,
        attempts INTEGER NOT NULL DEFAULT 0,
        last_error TEXT,
        created_at TEXT NOT NULL,
        acknowledged_at TEXT
    );
    """)
    c.commit()
    c.close()


def init_central():
    c = db(CENTRAL_DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS processed_messages (
        idempotency_key TEXT PRIMARY KEY,
        central_order_id TEXT NOT NULL,
        processed_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
        central_order_id TEXT PRIMARY KEY,
        idempotency_key TEXT NOT NULL UNIQUE,
        store_id TEXT NOT NULL,
        register_id TEXT NOT NULL,
        receipt_no INTEGER NOT NULL,
        sku TEXT NOT NULL,
        quantity INTEGER NOT NULL,
        total_cents INTEGER NOT NULL,
        created_at TEXT NOT NULL
    );
    """)
    c.commit()
    c.close()


def reset():
    for path in (STORE_DB, CENTRAL_DB, KAFKA_LOG):
        if os.path.exists(path):
            os.remove(path)
    init_store()
    init_central()


def create_offline_sale(store_id, register_id, receipt_no, sku, qty, total_cents):
    message_id = str(uuid.uuid4())
    local_sale_id = str(uuid.uuid4())
    idem = f"{store_id}|{register_id}|2026-08-29|{receipt_no:06d}"
    payload = {
        "message_id": message_id,
        "idempotency_key": idem,
        "store_id": store_id,
        "register_id": register_id,
        "receipt_no": receipt_no,
        "sku": sku,
        "quantity": qty,
        "total_cents": total_cents,
        "payment_status": "OFFLINE_APPROVED",
        "created_at": now(),
    }
    c = db(STORE_DB)
    try:
        c.execute("BEGIN")
        c.execute("""INSERT INTO sales VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (local_sale_id, store_id, register_id, receipt_no, sku, qty,
                   total_cents, "OFFLINE_APPROVED", payload["created_at"], "PENDING_SYNC"))
        c.execute("""INSERT INTO outbox
                   (message_id, idempotency_key, message_type, payload, status, attempts, created_at)
                   VALUES (?, ?, ?, ?, 'PENDING', 0, ?)""",
                  (message_id, idem, "OfflineSaleCommand", json.dumps(payload), payload["created_at"]))
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()
    return local_sale_id, idem


def central_ingest(payload):
    c = db(CENTRAL_DB)
    idem = payload["idempotency_key"]
    existing = c.execute("SELECT central_order_id FROM processed_messages WHERE idempotency_key = ?", (idem,)).fetchone()
    if existing:
        c.close()
        return existing["central_order_id"], "ALREADY_PROCESSED"

    order_id = "ORD-" + uuid.uuid4().hex[:12].upper()
    try:
        c.execute("BEGIN")
        c.execute("""INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                  (order_id, idem, payload["store_id"], payload["register_id"], payload["receipt_no"],
                   payload["sku"], payload["quantity"], payload["total_cents"], payload["created_at"]))
        c.execute("INSERT INTO processed_messages VALUES (?, ?, ?)", (idem, order_id, now()))
        c.commit()
    except sqlite3.IntegrityError:
        c.rollback()
        row = c.execute("SELECT central_order_id FROM processed_messages WHERE idempotency_key = ?", (idem,)).fetchone()
        c.close()
        return row["central_order_id"], "ALREADY_PROCESSED"
    c.close()

    event = {
        "event_id": str(uuid.uuid4()),
        "event_type": "OrderCreated",
        "event_version": 1,
        "key": order_id,
        "occurred_at": now(),
        "data": {"central_order_id": order_id, **payload},
    }
    with open(KAFKA_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")
    return order_id, "ACCEPTED"


def sync_once(connectivity=True):
    c = db(STORE_DB)
    rows = c.execute("SELECT * FROM outbox WHERE status IN ('PENDING', 'RETRYING') ORDER BY created_at").fetchall()
    if not rows:
        print("SYNC: no pending messages")
        c.close()
        return
    for row in rows:
        c.execute("UPDATE outbox SET status='SENDING', attempts=attempts+1 WHERE message_id=?", (row["message_id"],))
        c.commit()
        if not connectivity:
            c.execute("UPDATE outbox SET status='RETRYING', last_error=? WHERE message_id=?",
                      ("NETWORK_UNAVAILABLE", row["message_id"]))
            c.commit()
            print(f"SYNC: network unavailable; retained {row['idempotency_key']}")
            continue
        payload = json.loads(row["payload"])
        order_id, result = central_ingest(payload)
        c.execute("UPDATE outbox SET status='ACKNOWLEDGED', acknowledged_at=? WHERE message_id=?", (now(), row["message_id"]))
        c.execute("UPDATE sales SET sync_status='SYNCED' WHERE local_sale_id IN (SELECT local_sale_id FROM sales WHERE receipt_no=?)", (payload["receipt_no"],))
        c.commit()
        print(f"SYNC: {result}; {row['idempotency_key']} -> {order_id}")
    c.close()


def show_state():
    s = db(STORE_DB)
    print("\nSTORE SALES")
    for r in s.execute("SELECT receipt_no, total_cents, sync_status FROM sales ORDER BY receipt_no"):
        print(dict(r))
    print("STORE OUTBOX")
    for r in s.execute("SELECT idempotency_key, status, attempts, last_error FROM outbox"):
        print(dict(r))
    s.close()
    c = db(CENTRAL_DB)
    print("CENTRAL ORDERS")
    for r in c.execute("SELECT central_order_id, idempotency_key, total_cents FROM orders"):
        print(dict(r))
    c.close()
    count = 0
    if os.path.exists(KAFKA_LOG):
        with open(KAFKA_LOG, encoding="utf-8") as f:
            count = sum(1 for _ in f)
    print(f"KAFKA EVENT LOG: {count} event(s)")


if __name__ == "__main__":
    reset()
    print("1) Store loses internet and accepts a permitted offline sale")
    _, key = create_offline_sale("STORE-104", "REGISTER-03", 184, "SKU-1001", 2, 2598)
    print(f"POS: committed local sale and outbox atomically: {key}")
    show_state()

    print("\n2) Sync agent runs while connectivity is still down")
    sync_once(connectivity=False)
    show_state()

    print("\n3) Connectivity returns; sync agent retries")
    sync_once(connectivity=True)
    show_state()

    print("\n4) Demonstrate safe duplicate retry against central ingestion")
    c = db(STORE_DB)
    duplicate_payload = json.loads(c.execute("SELECT payload FROM outbox LIMIT 1").fetchone()["payload"])
    c.close()
    order_id, result = central_ingest(duplicate_payload)
    print(f"DUPLICATE: {result}; returned original central order {order_id}")
    print("No duplicate central order is created because the idempotency key is unique.")
