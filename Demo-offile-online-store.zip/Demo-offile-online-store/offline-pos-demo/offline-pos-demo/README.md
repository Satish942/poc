# Offline POS Store-Edge Infrastructure Demonstration

This demonstration models the recommended architecture:

```text
Store POS -> Local POS API -> Local SQLite DB + Transactional Outbox
                                      |
                               Sync Agent
                                      |
                         HTTPS/mTLS through Kong
                                      |
                     Central Ingestion API / Java Services
                                      |
                       Central DB + Central Outbox -> Kafka
```

## Run the demonstration

The sandbox does not have Docker installed, so the executable demonstration uses Python and SQLite and represents the Kafka event stream as an append-only JSON Lines log. The same data-flow contracts apply when the central event log is replaced by Apache Kafka.

```bash
cd /home/ubuntu/offline-pos-demo
python3 demo.py
```

The demonstration performs four actions:

1. Creates a sale while the store is offline.
2. Persists the sale and outbox record atomically in the local database.
3. Attempts synchronization while connectivity is down; the outbox remains retryable.
4. Restores connectivity, synchronizes the sale, writes a central order, and appends an `OrderCreated` event.

The resulting files are `store_pos.db`, `central.db`, and `kafka_events.jsonl`.

## Production infrastructure blueprint

The following is the recommended production separation. The exact DaoCloud resource names should be mapped to your organisation’s DCE version and platform standards.

### Store edge

| Component | Deployment | Responsibility |
|---|---|---|
| POS UI | Managed POS device | React cashier and associate interface |
| Local POS API | One or more local processes | Local validation, transaction boundary, device adapters |
| Local DB | Encrypted SQLite or approved embedded relational DB | Sale, payment evidence, register state, cache, outbox |
| Sync agent | Separate supervised process | Upload pending outbox, download deltas, retry, checkpoint, health reporting |
| Local monitoring | Store device/edge agent | Connectivity, disk, clock, process and outbox alerts |

### Central DaoCloud platform

| Component | Deployment | Responsibility |
|---|---|---|
| Kong Gateway | Highly available Kubernetes deployment | TLS, authentication, mTLS, rate limiting, routing and observability |
| POS Sync API | Stateless Java service | Batch upload, idempotency, acknowledgement and sync checkpoints |
| Domain services | Stateless Java microservices | Order, inventory, payment, pricing, customer and fulfilment ownership |
| Central databases | Stateful managed/DaoCloud-supported services | Service-owned transactional state |
| Central outbox publisher | Worker deployment | Publish committed domain events to Kafka |
| Kafka | Replicated central cluster | Durable event stream, fan-out, retention and replay |
| Schema Registry | Highly available service | Event schema validation and compatibility |
| Observability | DaoCloud/platform monitoring | Logs, metrics, traces, lag and store health |

## Important production rules

The local sale and local outbox row must be committed in one transaction. The central ingestion API must make the store idempotency key unique and return the original central order ID for retries. Every message should have a correlation ID, message ID, event type, event version, store ID, register ID, business date, and creation time.

The POS should not connect directly to central Kafka brokers. The POS communicates with the central synchronization API over authenticated HTTPS. Central domain services publish events to Kafka through a central outbox publisher. This keeps Kafka credentials and broker connectivity out of the store devices and allows Kong to enforce edge security.

## Example Kubernetes-style configuration boundaries

Use separate namespaces or equivalent platform projects such as:

```text
retail-edge-management
retail-gateway
retail-commerce
retail-integration
retail-messaging
retail-observability
```

Apply resource quotas, network policies, pod disruption budgets, secret management, TLS certificates, backup policies, and separate service accounts. Kafka and databases are stateful and should use replicated storage, tested backups, and failure-domain placement.

## Recommended next step

Replace the Python central-ingestion simulation with a Java POS Sync API and replace the JSON Lines event log with Kafka. Preserve the same contracts: local outbox states, idempotency key, per-message acknowledgement, retry lease, schema version, and reconciliation exception handling.
